/*
 * Created on Jul 17, 2004
 *
 */
package org.hailfire;

import josx.platform.rcx.*;

/**
 * The <tt>motors</tt> classes send the actual commands to the motors via the Motor class.
 * All other classes call this class to move the bot.
 * left motor = C
 * center motor = B
 * right motor = A
 * 
 * @author scott
 * @version 0.1 - 07/17/04 created
 * @version 0.2 - 07/18/04 added constructor, documentation
 */
public class motors {
    
    private int ACC_SPEED = 125;

    /*
     * default contstuctor to create <tt>motors</tt> object.
     */
    public motors() {
        super();
    }


    /*
     * The <tt>goForward</tt> method tells the A and C motors to go foward at power level <tt>speed</tt> (0-8)
     * @params direction "forwards" or "backward"
     * @params speed integer value from 0 to 8
     */
    public void drive(String direction, int speed) {
        //TextLCD.print("drive");
        try{Thread.sleep(1000);} catch(Exception e) {}
        if(direction.equals("backward")) {
            Motor.A.backward();
            Motor.C.backward();
        } else {
            Motor.A.forward();
            Motor.C.forward();
        }
        /*
        //if we arent at top speed, accelerate to it, else do nothing.
        if(Motor.A.getPower() != speed && Motor.B.getPower() != speed) {
	        for(int i=0; i <= speed; i=i+1) {
	            //TextLCD.print("acc");
		        Motor.A.setPower(i);
		        Motor.C.setPower(i);
		        Sound.beep();
		        try{Thread.sleep(ACC_SPEED);} catch(Exception e) {}
	        }
        }
        */
        Motor.A.setPower(speed);
        Motor.C.setPower(speed);
        
    }
    
    /*
     * The <tt>slowDown</tt> method is used to gradually slow down.
     * @params direction "forwards" or "backward"
     * @params lSpeed integer value from 0 to 8 for top speed.
     */    
    public void slowDown(String direction, int sSpeed, int eSpeed) {
        //TextLCD.print("slow");
        if(direction.equals("backward")) {
            Motor.A.backward();
            Motor.C.backward();
        } else {
            Motor.A.forward();
            Motor.C.forward();
        }
        
        for(int i=sSpeed; i >= eSpeed; i=i-1) {
	        Motor.A.setPower(i);
	        Motor.C.setPower(i);
	        Sound.beep();
	        try{Thread.sleep(ACC_SPEED);} catch(Exception e) {}
        }

        Motor.A.stop();
        Motor.C.stop();
    }

    /*
     * The <tt>turn</tt> method tells the A and C motors to go foward at different power levels
     * Used for making wide turns. Use rotate() for turning in place. 
     * using <tt>lSpeed</tt> and <tt>rSpeed</tt>.
     * @params direction "forwards" or "backward"
     * @params lSpeed integer value from 0 to 8
     * @params rSpeed integer value from 0 to 8
     */
    public void turn(String direction, int lSpeed, int rSpeed) {
        //TextLCD.print("turn");
        if(direction.equals("backward")) {
            Motor.A.backward();
            Motor.C.backward();
        } else {
            Motor.A.forward();
            Motor.C.forward();
        }
        
        Motor.A.setPower(lSpeed);
        Motor.C.setPower(rSpeed);
        
    }    

    /*
     * The <tt>rotate</tt> method tells the A and C motors to go opposite directions at the same power level.
     * Used for to rotate the bot in place.  
     * using <tt>lSpeed</tt> and <tt>rSpeed</tt>.
     * @params direction "left" or "right"
     * @params lSpeed integer value from 0 to 8
     * @params rSpeed integer value from 0 to 8
     */
    public void rotate(String direction, int speed) {
        //TextLCD.print(direction);
        if(direction.equals("left")) {
            Motor.A.backward();
            Motor.C.forward();
        } else {
            Motor.A.forward();
            Motor.C.backward();
        }
        
        Motor.A.setPower(speed);
        Motor.C.setPower(speed);
        
    }    
    
    /*
     * The <tt>allStop</tt> method tells the all 3 motors to stop and cuts all power.
     */    
    public void allStop() {
        Motor.A.setPower(0);
        Motor.B.setPower(0);
        Motor.C.setPower(0);
        
        Motor.A.stop();
        Motor.B.stop();
        Motor.C.stop();
    }
  
}
