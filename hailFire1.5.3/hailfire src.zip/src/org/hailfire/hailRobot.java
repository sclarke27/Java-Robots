/*
 * Created on Jul 17, 2004
 *
 */
package org.hailfire;

import josx.platform.rcx.*;

/**
 * @author scott
 *
 */
class hailRobot {
    
    
    
    public static void main(String[] args) 
    {
        // run the bot.
        runBot();
        // wait for run button to be pressed
        try{Button.RUN.waitForPressAndRelease();} catch(InterruptedException ie) {}
        
    }

    public static void runBot() {

        
        // create driving behavior thread from sense abstract class in sensors.java
        Sense memBehavior = new SenseNoOwner(new actuator(botActions.checkBattery()));
        memBehavior.setPri(Thread.MIN_PRIORITY);

        // create driving behavior thread from sense abstract class in sensors.java
        Sense mainBehavior = new SenseNoOwner(new actuator(botActions.doDriveForward()));
        mainBehavior.setPri(Thread.MIN_PRIORITY + 1);

        // create driving behavior thread from sense abstract class in sensors.java
        Sense avoidLeft = new SenseBumper(Sensor.S3, new actuator(botActions.collision("right")));
        avoidLeft.setPri(Thread.MIN_PRIORITY + 1);

        // create driving behavior thread from sense abstract class in sensors.java
        Sense avoidRight = new SenseBumper(Sensor.S1, new actuator(botActions.collision("left")));
        avoidRight.setPri(Thread.MIN_PRIORITY + 1);
        
        // set current thread to max priority
        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        
        // run behavior threads
        memBehavior.runIt();
        mainBehavior.runIt();
        avoidLeft.runIt();
        avoidRight.runIt();
        
        
    }
    
    
    
}
