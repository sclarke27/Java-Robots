/*
 * Created on Jul 18, 2004
 *
 */

package org.hailfire;

import java.lang.String;
import josx.robotics.*;
import josx.platform.rcx.*;

/**
 * The <tt>botActions</tt> contains a library of actions the bot can take. 
 * Each method contains an Action[] array.
 * 
 * @author scott
 * @version 0.1 07/18/04 - created.
 * 
 */
public class botActions {

    /**
     * default constructor class
     */
    public botActions() {
    }

    //private motor object constructor
    private static motors motor = new motors();
 
    
    /**
     * The <tt>doDriveForward</tt> returns an Action[] array for driving the bot forward.
     * @return action list
     * @see org.hailfire.motor#goForward()
     */
    public static Action[] doDriveForward() {
        Action[] actions = new Action[2];
        
        // go forward
        actions[0] = new Action() {
		    /* go forward at full speed.
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        motor.drive("forward",7);
		        return 3000;
		    }
		
		    /* nothing else to do but go forward
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return 0;
		    }
        };
        
        return actions;
    }

    /**
     * The <tt>collision</tt> returns an Action[] array for driving the bot forward.
     * @return action list
     * @see org.hailfire.motor#turnBot()
     */
    public static Action[] collision(String side) {
        Action[] actions = new Action[5];
        String tempStr;
        
        if(side.equals("left")) {
            tempStr = "right";
        } else {
            tempStr = "left";
        }
        
        final String turnDirection = tempStr;
        
        // stop 
        actions[0] = new Action() {
		    /* turn all motor motors off and cut power.
		     * @see org.hailfire.Action#act()
		     * @see org.hailfire.motors#allStop()
		     */
		    public int act() {
		        motor.allStop();
		        return 500;
		    }
		
		    /* goto next action step
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return 1;
		    }
        };
        
        // back up 
        actions[1] = new Action() {
		    /* go backwards at full speed.
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        motor.drive("backward",7);
		        return 250;
		    }
		
		    /* goto next action step
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return 2;
		    }
        };        

        // slow down
        actions[2] = new Action() {
		    /* call slowdown motor method
		     * @see org.hailfire.Action#act()
		     */
            
		    public int act() {
		        motor.slowDown("backward",7,0);
		        return 500;
		    }
		
		    /* goto next action step
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return 3;
		    }
        };        

        // turn 
        actions[3] = new Action() {
		    /* turn off right motor and set left motor to full power
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        motor.rotate(turnDirection,7);
		        return 500;
		    }
		
		    /* nothing else to do but go forward
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return 4;
		    }
        };

        // all stop
        actions[4] = new Action() {
		    /* call allStop()
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        motor.allStop();
		        return 500;
		    }
		
		    /* nothing else to do but go forward
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return Action.END;
		    }
        };
        
        return actions;
    } //end action collision
    
    public static Action[] checkMemory() {
        Action[] actions = new Action[1];
        
        actions[0] = new Action() {
		    /* show available memory on lcd
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        int tempNum = (int)(Runtime.getRuntime().freeMemory());
		        //LCD.showNumber(tempNum);
		        return 5;
		    }
		
		    /* nothing else to do but go forward
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return Action.END;
		    }
        };
        
        return actions;
    }
    
    public static Action[] checkBattery() {
        Action[] actions = new Action[1];
        
        actions[0] = new Action() {
		    /* show available memory on lcd
		     * @see org.hailfire.Action#act()
		     */
		    public int act() {
		        //LCD.showNumber(Battery.getVoltageInternal());
		        TextLCD.print("bat");
		        return 10;
		    }
			
		    /* nothing else to do but go forward
		     * @see org.hailfire.Action#nextState()
		     */
		    public int nextState() {
		        return Action.END;
		    }
        };
        
        return actions;

    }

}
